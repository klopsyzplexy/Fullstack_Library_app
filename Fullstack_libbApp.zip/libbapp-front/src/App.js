import React, { useState, useEffect } from 'react';
import axios from 'axios';
import NavBar from './components/NavBar';
import './App.css';

function App() {
  const [books, setBooks] = useState([]);
  const [filters, setFilters] = useState({ author: '', genre: '' });

  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const result = await axios.get('http://54.164.112.130:8000/api/books/', {
          params: { ...filters }
        });
        setBooks(result.data);
      } catch (error) {
        console.error('Error fetching books:', error);
      }
    };

    fetchBooks();
  }, [filters]);

  return (
    <div>
      <NavBar />
      <div style={{ padding: '20px' }}>
        <input
          value={filters.genre}
          onChange={(e) => setFilters({ ...filters, genre: e.target.value })}
          placeholder="Filter by Genre"
          style={{ marginRight: '10px' }}
        />
        <input
          value={filters.author}
          onChange={(e) => setFilters({ ...filters, author: e.target.value })}
          placeholder="Filter by Author"
        />
        <ul>
          {books.map(book => (
            <li key={book.id}>{book.title} - {book.author} - {book.genre}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default App;
