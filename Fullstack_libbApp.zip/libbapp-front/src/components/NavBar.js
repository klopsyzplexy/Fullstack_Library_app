import React, { useState } from 'react';
import './NavBar.css';

function NavBar() {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <nav className="navbar">
            <div className="logo">LibbApp</div>
            <div className="menu-icon" onClick={() => setIsOpen(!isOpen)}>
                <i>{isOpen ? 'Close' : 'Menu'}</i>
            </div>
            {isOpen && (
                <ul className="menu">
                    Created by klopsyzplexy
                </ul>
            )}
        </nav>
    );
}

export default NavBar;
